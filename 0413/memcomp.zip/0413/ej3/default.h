#ifndef __default_colchonera_H
#define __default_colchonera_H
#endif

#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <string.h>
#include <unistd.h>
#include "memoria_compartida.h"
#include "semaforo.h"

#define CANTIDAD 5
#define DESDE 1
#define HASTA 99
#define CLAVE_BASE 33