#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/ipc.h>
#include <sys/sem.h>
#include<time.h>
#include "semaforo.h"

#define CANTIDAD_MAXIMA 	10
#define LARGO 			100

struct deposito
{
    int importe;
    int is_efvo;
};

typedef struct deposito Deposito;


int main(int argc, char *argv[])
{
    srand(time(NULL));
	FILE *productor; 
    int importe, is_efvo, random_wait, random_quantity;
	int id_semaforo =  creo_semaforo();
	
	while(1)
	{
        random_wait = (rand() % (2500 - 1000 + 1)) + 1000;
        random_quantity = (rand() % (20 - 10 + 1)) + 10;
        Deposito depositos[random_quantity];
		espera_semaforo(id_semaforo);
        for (int i = 0; i < random_quantity; i++)
        {
            depositos[i].importe = (rand() % (500 - 100 + 1)) + 100;
            depositos[i].is_efvo = (rand() % (1 - 0 + 1)) + 0;
        }
        
        char *file_name = malloc(sizeof(char) * 12);
        sprintf(file_name, "%s.dat", argv[0]);
        productor = fopen(file_name, "a");
        if(productor != NULL) {
            for (int i = 0; i < random_quantity; i++) {
                fprintf(productor, "%d %d \n", depositos[i].importe, depositos[i].is_efvo);
            }
            fclose(productor);
        } else {
            perror ("Error al abrir el archivo");
        }

        levanta_semaforo(id_semaforo);

        usleep(random_wait*1000);
        }

	    return 0;
}
