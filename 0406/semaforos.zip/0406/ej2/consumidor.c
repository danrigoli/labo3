#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <sys/ipc.h>
#include <sys/sem.h>
#include "semaforo.h"

#define CANTIDAD_CAJEROS	3
#define INTERVALO_PARTIDA 	500
#define LARGO 			100

struct cajero
{
    int cant_efvo;
    int total_efvo;
    int cant_cheq;
    int total_cheq;
};

typedef struct cajero Cajero;

int main()
{

	FILE *consumidor; 
	int lote_id = 0;
    Cajero cajeros[CANTIDAD_CAJEROS];
    int position = 0;
	int id_semaforo =  creo_semaforo();
    inicia_semaforo(id_semaforo, 1);
    int deposito;
    int is_efvo;
    char nombre_pasajero[LARGO];
	while(1)
	{
		espera_semaforo(id_semaforo);
            for(int i = 0; i < CANTIDAD_CAJEROS; i++) {
                    char *file_name = malloc(sizeof(char) * 15);
                sprintf(file_name, "cajero%d.dat", i + 1);
			    consumidor = fopen(file_name, "r");
			    if (consumidor!=NULL)
			    {
				    while (!feof(consumidor))
				    {
				    	fscanf(consumidor,"%d %d", &deposito, &is_efvo);
                      if (is_efvo == 0) {
                          cajeros[i].cant_efvo++;
                           cajeros[i].total_efvo += deposito;
                        } else {
                            cajeros[i].cant_cheq++;
                            cajeros[i].total_cheq += deposito;
                        }
				    }
				    fclose(consumidor);
                    printf("TOTAL \n");
                    printf("CAJERO%d", i + 1);
                    printf("TC-EFEC  T$-EFEC  TC-CHEQ  T$-CHEQ\n");
                    printf("%d       %d     %d      %d\n", cajeros[i].cant_efvo, cajeros[i].total_efvo, cajeros[i].cant_cheq, cajeros[i].total_cheq);
                } else printf ("Error al cargar el cajero %d \n", i + 1);
                char *new_file_name = malloc(sizeof(char) * 15);
                sprintf(new_file_name, "cajero%d.%d.dat", i + 1, lote_id);
                rename(file_name, new_file_name);
            }
				lote_id++;						
		levanta_semaforo(id_semaforo);
		usleep(INTERVALO_PARTIDA*10000);
	};
	return 0;
}
