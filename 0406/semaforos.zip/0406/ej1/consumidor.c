#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <sys/ipc.h>
#include <sys/sem.h>
#include "semaforo.h"

#define CANTIDAD_VUELOS 	11
#define INTERVALO_PARTIDA 	300
#define ROJO  			0
#define VERDE 			1
#define LARGO 			100

struct flight
{
    int vuelo;
    char destino[LARGO];
    int pasajeros;
};

typedef struct flight Flight;

int main()
{

	FILE *consumidor; 
	int lote_id = 0;
    Flight vuelos[CANTIDAD_VUELOS];
    int position = 0;
	int id_semaforo =  creo_semaforo();
    int nro_vuelo;
    char destino[LARGO];
    char nombre_pasajero[LARGO];
	while(1)
	{
		espera_semaforo(id_semaforo);
			
			consumidor = fopen("lote.dat", "r");
			if (consumidor!=NULL)
			{
				while (!feof(consumidor))
				{
					fscanf(consumidor,"%d %s %s", &nro_vuelo, destino, nombre_pasajero);
                    position = nro_vuelo % 100;
                    if (vuelos[position].vuelo != nro_vuelo) {
                        vuelos[position].vuelo = nro_vuelo;
                        strcpy(vuelos[position].destino, destino);
                        vuelos[position].pasajeros = 1;
                    } else vuelos[position].pasajeros++;
				}
				fclose(consumidor);
                printf("VUELO    DESTINO    PASAJEROS\n");
                for(int i = 0; i < CANTIDAD_VUELOS; i++) {
                    if (vuelos[i].vuelo <= 1010 && vuelos[i].vuelo >= 1000) {
                        printf("%d     %s     %d\n", vuelos[i].vuelo, vuelos[i].destino, vuelos[i].pasajeros);
                    }
                }
                char *file_name = malloc(sizeof(char) * 15);
                sprintf(file_name, "lote.%d.dat", lote_id);
                rename("lote.dat", file_name);
				lote_id++;
			}
			else perror ("Error al cargar lote");
						
		levanta_semaforo(id_semaforo);
		usleep(INTERVALO_PARTIDA*1000);
	};
	return 0;
}
