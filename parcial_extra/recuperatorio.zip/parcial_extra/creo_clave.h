#ifndef __clave_H
#define __clave_H
#endif

key_t creo_clave(int r_clave);