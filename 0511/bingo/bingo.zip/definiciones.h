#ifndef _DEFINICIONES_H
#define _DEFINICIONES_H
 


typedef enum
{
	MSG_NADIE,
	MSG_BINGO,
	MSG_JUGADOR
} Destinos;

typedef enum
{
	EVT_NINGUNO,
	EVT_BOLILLA,
	EVT_CARTON_LLENO
} Eventos;


#endif
